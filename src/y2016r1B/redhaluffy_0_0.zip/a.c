#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 2001

int main(int argc, char **argv)
{
	FILE *f = fopen(argv[1], "r");
	int T, i, j;
	int n[26], res[10];
	char S[SIZE];

	fscanf(f, "%d\n", &T);

	for (i = 0; i < T; i++) {
		fscanf(f, "%s\n", S);
		memset(n, 0, 26 * sizeof(int));
		memset(res, 0, 10 * sizeof(int));
		for (j = 0; j < SIZE && S[j] != '\0'; j++) {
			n[S[j] - 'A'] += 1;
		}
		// ZEROs
		for (j = 0; j < n['Z' - 'A']; ) {
			n['Z' - 'A']--;
			n['E' - 'A']--;
			n['R' - 'A']--;
			n['O' - 'A']--;
			res[0]++;
		}
		// SIX
		for (j = 0; j < n['X' - 'A']; ) {
			n['S' - 'A']--;
			n['I' - 'A']--;
			n['X' - 'A']--;
			res[6]++;
		}
		// TWO
		for (j = 0; j < n['W' - 'A']; ) {
			n['T' - 'A']--;
			n['W' - 'A']--;
			n['O' - 'A']--;
			res[2]++;
		}
		// EIGHT
		for (j = 0; j < n['G' - 'A']; ) {
			n['E' - 'A']--;
			n['I' - 'A']--;
			n['G' - 'A']--;
			n['H' - 'A']--;
			n['T' - 'A']--;
			res[8]++;
		}
		// SEVEN
		for (j = 0; j < n['S' - 'A']; ) {
			n['S' - 'A']--;
			n['E' - 'A']--;
			n['V' - 'A']--;
			n['E' - 'A']--;
			n['N' - 'A']--;
			res[7]++;
		}
		// FIVE
		for (j = 0; j < n['V' - 'A']; ) {
			n['F' - 'A']--;
			n['I' - 'A']--;
			n['V' - 'A']--;
			n['E' - 'A']--;
			res[5]++;
		}
		// NINE
		for (j = 0; j < n['I' - 'A']; ) {
			n['N' - 'A']--;
			n['I' - 'A']--;
			n['N' - 'A']--;
			n['E' - 'A']--;
			res[9]++;
		}
		// ONE
		for (j = 0; j < n['N' - 'A']; ) {
			n['O' - 'A']--;
			n['N' - 'A']--;
			n['E' - 'A']--;
			res[1]++;
		}
		// FOUR
		for (j = 0; j < n['F' - 'A']; ) {
			n['F' - 'A']--;
			n['O' - 'A']--;
			n['U' - 'A']--;
			n['R' - 'A']--;
			res[4]++;
		}
		// THREE
		for (j = 0; j < n['T' - 'A']; ) {
			n['T' - 'A']--;
			n['H' - 'A']--;
			n['R' - 'A']--;
			n['E' - 'A']--;
			n['E' - 'A']--;
			res[3]++;
		}
		printf("Case #%d: ", i+1);
		for (j = 0; j < 10; j++) {
			/* printf("res[%d] = %d\n", j, res[j]); */
			while (res[j] > 0) {
				printf("%d", j);
				res[j]--;
			}
		}
		printf("\n");
	}

	fclose(f);

	return 0;
}
